﻿using AnalisisDBContext.Models;
using BusinessLogic;
using DTOs;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Managers.Tests
{
    [TestFixture]
    public class ResultadoTest
    {
        private Mock<IPatologiaRepository> mockPatologiaAnalisisRepository;
        private List<Patologia> patologiaResult;

        [Test]
        public void testResultado_notNull()
        {
            //Arrange
            int patologiaID = 1;
            prepareMockRepositories();

            //Act
            Resultado resultadoManager = new Resultado(mockPatologiaAnalisisRepository.Object);
            ResultadoDTO result = resultadoManager.getResultadoByPatologia(patologiaID);

            //Assert
            Assert.IsTrue(result != null, "El resultado es nulo");
        }

        [Test]
        public void testResultado_isOK()
        {
            //Arrange
            int patologiaID = 1;
            prepareMockRepositories();

            //Act
            Resultado resultadoManager = new Resultado(mockPatologiaAnalisisRepository.Object);
            ResultadoDTO result = resultadoManager.getResultadoByPatologia(patologiaID);

            //Assert
            Assert.AreEqual("Enfermedad cardíaca", result.Nombre, "El resultado no es el esperado");
        }

        #region privateMethods

        private void fillPatologiaResultMock()
        {
            patologiaResult = new List<Patologia>();

            Patologia currentPatologia = new Patologia();
            currentPatologia.Nombre = "Enfermedad cardíaca";
            currentPatologia.Descripcion = "El elevado colesterol casa obstrucción de los vasos sanguíneos y paros cardiacos";
            currentPatologia.PatologiaId = 1;
            currentPatologia.Riesgos = "infarto";
            currentPatologia.Tratamiento = "medicamentos para diluir la sangre";
            currentPatologia.Recomendaciones = "acuda a su médico, haga ejercicio y coma más sano";

            patologiaResult.Add(currentPatologia);
        }

        private void prepareMockRepositories()
        {
           mockPatologiaAnalisisRepository = new Mock<IPatologiaRepository>();
            fillPatologiaResultMock();
            mockPatologiaAnalisisRepository.Setup(mr => mr.GetPatologias()).Returns(patologiaResult);
        }

        #endregion
    }
}
