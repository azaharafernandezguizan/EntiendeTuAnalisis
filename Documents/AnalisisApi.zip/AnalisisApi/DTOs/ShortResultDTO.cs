﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTOs
{
    public class ShortResultDTO
    {
        public ShortResultDTO()
        {

        }

        public string PatologiaName { get; set; }
        public int PatologiaId { get; set; }
    }
}
