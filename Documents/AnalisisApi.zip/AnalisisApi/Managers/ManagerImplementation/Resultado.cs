﻿using AnalisisDBContext.Models;
using BusinessLogic;
using DTOs;
using Managers.IManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Managers
{
    public class Resultado : IResultado
    {
        public IPatologiaRepository patologiaRepository;

        public Resultado()
        {
            this.patologiaRepository = new PatologiaRepository(new AnalisisSchemaContext());
        }

        public Resultado(IPatologiaRepository patologiaRepository)
        {
            this.patologiaRepository = patologiaRepository;
        }

        public ResultadoDTO getResultadoByPatologia(int patologiaID)
        {
            List<Patologia> patologias = patologiaRepository.GetPatologias();

            Patologia patologia = patologias.Where(p => p.PatologiaId == patologiaID).FirstOrDefault();

            ResultadoDTO result = null;
            if(patologia!= null)
            {
                result = new ResultadoDTO();
                result.PatologiaId = patologiaID;
                result.Nombre = patologia.Nombre;
                result.Descripcion = patologia.Descripcion;
                result.Recomendaciones = patologia.Recomendaciones;
                result.Riesgos = patologia.Riesgos;
            }

            return result;
        }
    }
}
